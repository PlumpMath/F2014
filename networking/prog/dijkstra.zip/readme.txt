Readme for Dijkstra's algorithm project.

Implemented in C.

Currently unfinished. Implemented a priority queue to track nodes. Dijkstra's
implementation does not return proper output.

Summary is printed to output.txt. Routing tables are not implemented.

Attached is a simple Makefile to compile the code.
