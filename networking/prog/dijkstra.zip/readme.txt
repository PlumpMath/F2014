Readme for Dijkstra's algorithm project.

Implemented in C.

Finished. Implements proper Dijkstra's algorithm.

Summary and routing tables are printed to output.txt.

Attached is a simple Makefile to compile the code.

To build:                 make
To rebuild:               make rebuild
To remove compiled files: make clean
To run:                   ./dijkstra graph.txt
